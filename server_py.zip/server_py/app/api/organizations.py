from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.security import get_current_user
from app.models import User
from app.schemas.organization import OrganizationCreate, OrganizationOut
from app.repositories.organization_repository import OrganizationRepository

router = APIRouter(prefix="/organizations", tags=["organizations"])
repo = OrganizationRepository()

@router.post("", response_model=OrganizationOut, status_code=status.HTTP_201_CREATED)
def create_org(
    payload: OrganizationCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    # Per ora lo lasciamo semplice: se sei loggato puoi creare.
    # Se vuoi, dopo mettiamo ruoli come in Go.
    existing = repo.get_by_id(db, payload.id)
    if existing:
        raise HTTPException(status_code=409, detail="Organization already exists")

    org = repo.create(db, payload.id, payload.name)
    return OrganizationOut(id=org.id, name=org.name)

@router.get("/me", response_model=OrganizationOut)
def get_my_org(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if not current_user.organization_id:
        raise HTTPException(status_code=404, detail="User has no organization")
    org = repo.get_by_id(db, current_user.organization_id)
    if not org:
        raise HTTPException(status_code=404, detail="Organization not found")
    return OrganizationOut(id=org.id, name=org.name)

@router.get("/{org_id}", response_model=OrganizationOut)
def get_org(
    org_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    org = repo.get_by_id(db, org_id)
    if not org:
        raise HTTPException(status_code=404, detail="Organization not found")
    return OrganizationOut(id=org.id, name=org.name)

