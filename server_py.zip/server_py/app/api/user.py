from __future__ import annotations

from fastapi import APIRouter, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

from app.core.security import get_current_user
from app.models import User

router = APIRouter(tags=["user"])

# Optional auth (non deve esplodere se manca Authorization)
bearer_scheme = HTTPBearer(auto_error=False)


def _me_payload(current_user: User) -> dict:
    """
    Payload compatibile (il più possibile) con /me del backend Go.

    Nel Go:
      - id è UUID string
      - organization è oggetto con tanti campi
      - spaceAdmin/admin/superAdmin sono boolean
      - role è un int (nel Go è enum/numero)

    In Python al momento:
      - id è int
      - organization_id è string (es: "seatsurfing")
      - role è string (es: "org_admin", "super_admin", "admin", "user")
    """
    role_str = (current_user.role or "").lower()

    is_super_admin = role_str == "super_admin"
    is_org_admin = role_str in {"org_admin", "super_admin"}
    # se nel tuo progetto usi anche "admin" come space admin, includiamolo:
    is_space_admin = role_str in {"admin", "org_admin", "super_admin"}

    # In Go "requirePassword" è true se l'utente/org richiede password.
    # Senza settings/lookup DB, mettiamo True se ha una password valorizzata.
    require_password = bool(getattr(current_user, "hashed_password", "") or "")

    # full_name -> firstname/lastname (best-effort)
    full_name = (current_user.full_name or "").strip()
    firstname = ""
    lastname = ""
    if full_name:
        parts = full_name.split()
        firstname = parts[0]
        lastname = " ".join(parts[1:]) if len(parts) > 1 else ""

    org_id = current_user.organization_id or ""

    return {
        # nel Go è UUID; qui è int ma la UI di solito non ci muore
        "id": str(current_user.id),

        # oggetto organization (minimale, ma con tutte le chiavi che il FE spesso si aspetta)
        "organization": {
            "id": org_id,
            "name": "",  # se vuoi: puoi metterlo leggendo Organization dal DB
            "firstname": "",
            "lastname": "",
            "email": "",
            "language": "",
            "country": "",
            "addressLine1": "",
            "addressLine2": "",
            "postalCode": "",
            "city": "",
            "vatId": "",
            "company": "",
        },

        "requirePassword": require_password,

        # flags per UI
        "spaceAdmin": is_space_admin,
        "admin": is_org_admin,
        "superAdmin": is_super_admin,

        # info utente
        "email": current_user.email,
        "firstname": firstname,
        "lastname": lastname,
        "atlassianId": "",
        "role": 20 if is_org_admin else 10,  # numero "compat" (non perfetto, ma stabile per la UI)
        "authProviderId": "",
        "password": "",

        # in Go c'è anche organizationId top-level
        "organizationId": org_id,
    }


# FE usa /user/me (protetto: DEVE richiedere token)
@router.get("/user/me", response_model=dict)
def me(current_user: User = Depends(get_current_user)):
    return _me_payload(current_user)


# Alias utile: alcuni pezzi chiamano /users/me
@router.get("/users/me", response_model=dict)
def me_alias(current_user: User = Depends(get_current_user)):
    return _me_payload(current_user)


# FE usa /user/merge e SI ASPETTA UN ARRAY
# IMPORTANTISSIMO: deve tornare 200 e [] anche se manca il token
@router.get("/user/merge", response_model=list)
def merge(credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme)):
    return []