from fastapi import APIRouter

router = APIRouter(prefix="/setting", tags=["setting"])


@router.get("/")
def get_settings():
    return [
        {"key": "productName", "value": "Seatsurfing"},
        {"key": "productVersion", "value": "dev"},
        {"key": "allowUserRegistration", "value": "false"},
        {"key": "allowSelfRegistration", "value": "false"},
    ]