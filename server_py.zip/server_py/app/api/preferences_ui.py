from fastapi import APIRouter, Depends
from app.core.security import get_current_user
from app.models import User

router = APIRouter(prefix="/preference", tags=["ui-compat"])

@router.get("")
@router.get("/")
def list_preferences(current_user: User = Depends(get_current_user)):
    # ✅ NON restituire mai []
    # Il FE si aspetta qualcosa che contenga recurrence.weekdays (array)
    return [{
        "id": "default",
        "userId": str(current_user.id),
        "organizationId": current_user.organization_id,
        "recurrence": {
            "weekdays": []   # ✅ così `.includes(...)` non esplode
        }
    }]