from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.security import get_current_user
from app.models import User

router = APIRouter(prefix="/booking", tags=["ui-compat"])


@router.get("/pendingapprovals/count")
def pending_approvals_count(current_user: User = Depends(get_current_user)):
    return 0


@router.get("/filter")
def filter_bookings(
    start: str = Query(...),
    end: str = Query(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    # Stub: FE si aspetta una lista di bookings
    return []


@router.get("/")
@router.get("")
def list_bookings(
    current_user: User = Depends(get_current_user),
    enter: str | None = Query(default=None),
    leave: str | None = Query(default=None),
    location: str | None = Query(default=None),
    space: str | None = Query(default=None),
):
    return []