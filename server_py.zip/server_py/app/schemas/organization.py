from pydantic import BaseModel, Field

class OrganizationCreate(BaseModel):
    id: str = Field(..., description="Organization ID, es: seatsurfing")
    name: str


class OrganizationOut(BaseModel):
    id: str
    name: str
