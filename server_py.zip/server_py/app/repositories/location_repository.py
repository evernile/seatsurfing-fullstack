# app/repositories/location_repository.py

from __future__ import annotations

from sqlalchemy import asc
from sqlalchemy.orm import Session

from app.models import Location


class LocationRepository:
    # --- CRUD base (Go-like) ---

    def create(self, db: Session, e: Location) -> Location:
        db.add(e)
        db.commit()
        db.refresh(e)
        return e

    def get_one(self, db: Session, location_id: str) -> Location | None:
        return db.query(Location).filter(Location.id == location_id).first()

    def get_all(self, db: Session, organization_id: str) -> list[Location]:
        return (
            db.query(Location)
            .filter(Location.organization_id == organization_id)
            .order_by(asc(Location.name))
            .all()
        )

    def get_by_keyword(self, db: Session, organization_id: str, keyword: str) -> list[Location]:
        # Go fa LOWER(name) LIKE %keyword%
        kw = f"%{keyword.strip().lower()}%"
        return (
            db.query(Location)
            .filter(Location.organization_id == organization_id)
            .filter(Location.name.ilike(kw))
            .order_by(asc(Location.name))
            .all()
        )

    def update(self, db: Session, e: Location) -> Location:
        # e è già in sessione di solito, ma add() non fa male: garantisce l'attach
        db.add(e)
        db.commit()
        db.refresh(e)
        return e

    def delete(self, db: Session, e: Location) -> None:
        """
        Go fa cascade manuale:
        - delete bookings delle spaces della location
        - delete spaces della location
        - delete space_attribute_values entity_type=location
        - delete location
        Qui per ora cancelliamo solo la location (MVP).
        Quando portiamo Spaces/Bookings/Attributes "identici al Go",
        implementiamo qui la cascata esatta.
        """
        db.delete(e)
        db.commit()

    # --- Map (Go-like) ---

    def set_map(
        self,
        db: Session,
        e: Location,
        mime_type: str,
        data: bytes,
        width: int,
        height: int,
        scale: float,
    ) -> Location:
        e.map_mimetype = mime_type or ""
        e.map_data = data or b""
        e.map_width = int(width or 0)
        e.map_height = int(height or 0)
        e.map_scale = float(scale or 1.0)
        db.commit()
        db.refresh(e)
        return e

    def get_map(self, db: Session, e: Location) -> dict:
        # db non serve qui, ma lo teniamo per firma simile e futura estendibilità
        return {
            "mime_type": e.map_mimetype or "",
            "data": e.map_data or b"",
            "width": int(e.map_width or 0),
            "height": int(e.map_height or 0),
            "scale": float(e.map_scale or 1.0),
        }