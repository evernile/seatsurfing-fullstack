import uuid
from dataclasses import dataclass
from datetime import datetime
from typing import Optional

from sqlalchemy import and_, or_, asc
from sqlalchemy.orm import Session, joinedload

from app.models import Space, Booking, User, Location, SpaceApprover, SpaceAllowedBooker


@dataclass
class SpaceAvailabilityBookingEntry:
    booking_id: str
    recurring_id: str
    user_id: str
    user_email: str
    enter: datetime
    leave: datetime
    subject: str


@dataclass
class SpaceAvailability:
    space: Space
    available: bool
    bookings: list[SpaceAvailabilityBookingEntry]


@dataclass
class SpaceGroup:
    space_id: str
    group_id: str


class SpaceRepository:

    def create(self, db: Session, e: Space) -> Space:
        db.add(e)
        db.commit()
        db.refresh(e)
        return e

    def get_one(self, db: Session, space_public_id: str) -> Optional[Space]:
        try:
            spid = uuid.UUID(space_public_id)
        except Exception:
            return None
        return (
            db.query(Space)
            .options(joinedload(Space.location_rel))
            .filter(Space.public_id == spid)
            .first()
        )

    def get_all(self, db: Session, location_id: str) -> list[Space]:
        lid = uuid.UUID(location_id)
        return (
            db.query(Space)
            .filter(Space.location_id == lid)
            .order_by(asc(Space.name))
            .all()
        )

    def update(self, db: Session, e: Space) -> Space:
        db.add(e)
        db.commit()
        db.refresh(e)
        return e

    def delete(self, db: Session, space: Space) -> None:
        # Go cancella anche attributes/approvers/allowedbookers
        db.query(SpaceApprover).filter(SpaceApprover.space_id == space.public_id).delete(synchronize_session=False)
        db.query(SpaceAllowedBooker).filter(SpaceAllowedBooker.space_id == space.public_id).delete(synchronize_session=False)
        db.delete(space)
        db.commit()

    # --- Search by keyword (Go: GetByKeyword) ---

    def get_by_keyword(self, db: Session, organization_id: str, keyword: str) -> list[Space]:
        kw = f"%{keyword.lower()}%"
        return (
            db.query(Space)
            .join(Location, Location.id == Space.location_id)
            .filter(Location.organization_id == organization_id)
            .filter(Space.name.ilike(kw))
            .order_by(asc(Space.name))
            .all()
        )

    # --- Availability (Go: GetAllInTime) ---

    def get_all_in_time(self, db: Session, location_id: str, enter: datetime, leave: datetime) -> list[SpaceAvailability]:
        """
        Go fa una query unica con NOT EXISTS + array aggregata.
        Qui facciamo “semplice ma fedele”: per ogni space, prendo bookings overlapping.
        """
        lid = uuid.UUID(location_id)
        spaces = (
            db.query(Space)
            .filter(Space.location_id == lid)
            .order_by(asc(Space.name))
            .all()
        )

        res: list[SpaceAvailability] = []

        for sp in spaces:
            # Overlap condition come nel Go (equivalente):
            # booking.start < leave AND booking.end > enter
            # nel tuo DB “Go-like” userai enter_time/leave_time
            q = (
                db.query(Booking, User)
                .join(User, User.id == Booking.user_id)
                .filter(Booking.space_id == sp.id)
                .filter(Booking.is_active == True)
            )

            # se enter_time/leave_time sono valorizzati, usa quelli, altrimenti start_at/end_at
            q = q.filter(
                or_(
                    and_(Booking.enter_time != None, Booking.leave_time != None,
                         Booking.enter_time < leave, Booking.leave_time > enter),
                    and_(Booking.enter_time == None, Booking.leave_time == None,
                         Booking.start_at < leave, Booking.end_at > enter),
                )
            ).order_by(asc(Booking.enter_time), asc(Booking.start_at))

            rows = q.all()

            bookings: list[SpaceAvailabilityBookingEntry] = []
            for b, u in rows:
                b_enter = b.enter_time or b.start_at
                b_leave = b.leave_time or b.end_at
                bookings.append(
                    SpaceAvailabilityBookingEntry(
                        booking_id=str(b.public_id),
                        recurring_id=str(b.recurring_id or ""),
                        user_id=str(u.public_id),
                        user_email=str(u.email),
                        enter=b_enter,
                        leave=b_leave,
                        subject=str(b.subject or ""),
                    )
                )

            available = (len(bookings) == 0)
            res.append(SpaceAvailability(space=sp, available=available, bookings=bookings))

        return res

    def get_by_id_in_org(self, db: Session, organization_id: str, space_id: int) -> Space | None:
        return (
            db.query(Space)
            .filter(Space.organization_id == organization_id)
            .filter(Space.id == space_id)
            .first()
        )

    def get_approver_group_ids(self, db: Session, space_public_id: str) -> list[str]:
        try:
            spid = uuid.UUID(space_public_id)
        except Exception:
            return[]
        rows = (
            db.query(SpaceApprover.group_id)
            .filter(SpaceApprover.space_id == spid)
            .order_by(asc(SpaceApprover.group_id))
            .all()
        )
        return [str(r[0]) for r in rows]

    def add_approvers(self, db: Session, space_public_id: str, group_ids: list[str]) -> None:
        if not group_ids:
            return
        spid = uuid.UUID(space_public_id)
        for gid in group_ids:
            db.merge(SpaceApprover(space_id=spid, group_id=uuid.UUID(gid)))
        db.commit()

    def remove_approvers(self, db: Session, space_public_id: str, group_ids: list[str]) -> None:
        if not group_ids:
            return
        spid = uuid.UUID(space_public_id)
        gids = [uuid.UUID(g) for g in group_ids]
        db.query(SpaceApprover).filter(SpaceApprover.space_id == spid, SpaceApprover.group_id.in_(gids)).delete(synchronize_session=False)
        db.commit()

    def get_all_approvers_for_space_list(self, db: Session, space_public_ids: list[str]) -> list[SpaceGroup]:
        if not space_public_ids:
            return []
        spids = [uuid.UUID(s) for s in space_public_ids]
        rows = db.query(SpaceApprover.space_id, SpaceApprover.group_id).filter(SpaceApprover.space_id.in_(spids)).all()
        return [SpaceGroup(space_id=str(a), group_id=str(b)) for a, b in rows]

    def get_allowed_bookers_group_ids(self, db: Session, space_public_id: str) -> list[str]:
        spid = uuid.UUID(space_public_id)
        rows = (
            db.query(SpaceAllowedBooker.group_id)
            .filter(SpaceAllowedBooker.space_id == spid)
            .order_by(asc(SpaceAllowedBooker.group_id))
            .all()
        )
        return [str(r[0]) for r in rows]

    def add_allowed_bookers(self, db: Session, space_public_id: str, group_ids: list[str]) -> None:
        if not group_ids:
            return
        spid = uuid.UUID(space_public_id)
        for gid in group_ids:
            db.merge(SpaceAllowedBooker(space_id=spid, group_id=uuid.UUID(gid)))
        db.commit()

    def remove_allowed_bookers(self, db: Session, space_public_id: str, group_ids: list[str]) -> None:
        if not group_ids:
            return
        spid = uuid.UUID(space_public_id)
        gids = [uuid.UUID(g) for g in group_ids]
        db.query(SpaceAllowedBooker).filter(SpaceAllowedBooker.space_id == spid, SpaceAllowedBooker.group_id.in_(gids)).delete(synchronize_session=False)
        db.commit()

    def get_all_allowed_bookers_for_space_list(self, db: Session, space_public_ids: list[str]) -> list[SpaceGroup]:
        if not space_public_ids:
            return []
        spids = [uuid.UUID(s) for s in space_public_ids]
        rows = db.query(SpaceAllowedBooker.space_id, SpaceAllowedBooker.group_id).filter(SpaceAllowedBooker.space_id.in_(spids)).all()
        return [SpaceGroup(space_id=str(a), group_id=str(b)) for a, b in rows]