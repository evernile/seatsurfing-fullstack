import uuid
from typing import Optional
from sqlalchemy.orm import Session
from sqlalchemy import asc

from app.models import Group, UserGroup

class GroupRepository:
    def create(self, db: Session, e: Group) -> Group:
        db.add(e)
        db.commit()
        db.refresh(e)
        return e

    def get_one(self, db: Session, group_id: str) -> Optional[Group]:
        try:
            gid = uuid.UUID(group_id)
        except Exception:
            return None
        return db.query(Group).filter(Group.id == gid).first()

    def get_all(self, db: Session, organization_id: str) -> list[Group]:
        return (
            db.query(Group)
            .filter(Group.organization_id == organization_id)
            .order_by(asc(Group.name))
            .all()
        )

    def update(self, db: Session, e: Group) -> Group:
        db.add(e)
        db.commit()
        db.refresh(e)
        return e

    def delete(self, db: Session, e: Group) -> None:
        db.delete(e)
        db.commit()

    # ---- Membership ----

    def get_member_user_ids(self, db: Session, group_id: str) -> list[str]:
        try:
            gid = uuid.UUID(group_id)
        except Exception:
            return []
        rows = db.query(UserGroup.user_id).filter(UserGroup.group_id == gid).all()
        return [str(r[0]) for r in rows]

    def add_members(self, db: Session, group_id: str, user_public_ids: list[str]) -> None:
        gid = uuid.UUID(group_id)
        for uid in user_public_ids:
            db.merge(UserGroup(group_id=gid, user_id=uuid.UUID(uid)))
        db.commit()

    def remove_members(self, db: Session, group_id: str, user_public_ids: list[str]) -> None:
        gid = uuid.UUID(group_id)
        uids = [uuid.UUID(x) for x in user_public_ids]
        db.query(UserGroup).filter(
            UserGroup.group_id == gid,
            UserGroup.user_id.in_(uids),
        ).delete(synchronize_session=False)
        db.commit()

    def get_groups_where_user_is_member(self, db: Session, user_public_id: str) -> list[Group]:
        try:
            uid = uuid.UUID(user_public_id)
        except Exception:
            return []
        return (
            db.query(Group)
            .filter(Group.id.in_(
                db.query(UserGroup.group_id).filter(UserGroup.user_id == uid)
            ))
            .order_by(asc(Group.name))
            .all()
        )

    def get_user_group_ids(self, db: Session, user_public_id: str) -> set[str]:
        try:
            uid = uuid.UUID(user_public_id)
        except Exception:
            return set()
        rows = db.query(UserGroup.group_id).filter(UserGroup.user_id == uid).all()
        return {str(r[0]) for r in rows}