from __future__ import annotations

from datetime import datetime
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_

from app.models import Booking
from app.models import SpaceApprover, UserGroup, Space


class BookingRepository:
    def create(
        self,
        db: Session,
        organization_id: str,
        user_id: int,
        space_id: int,
        start_at: datetime,
        end_at: datetime,
        subject: str | None = None,
        recurring_id: str | None = None,
        status: str = "approved",
    ) -> Booking:
        booking = Booking(
            organization_id=organization_id,
            user_id=user_id,
            space_id=space_id,
            start_at=start_at,
            end_at=end_at,

            # Go-like shadow fields
            enter_time=start_at,
            leave_time=end_at,
            subject=subject,
            recurring_id=recurring_id,

            status=status,
            is_active=True,
        )
        db.add(booking)
        db.commit()
        db.refresh(booking)
        return booking

    def list_by_org(self, db: Session, organization_id: str) -> list[Booking]:
        return (
            db.query(Booking)
            .filter(Booking.organization_id == organization_id)
            .filter(Booking.is_active == True)
            .order_by(Booking.start_at.asc())
            .all()
        )

    def list_by_user_in_org(self, db: Session, organization_id: str, user_id: int) -> list[Booking]:
        return (
            db.query(Booking)
            .filter(Booking.organization_id == organization_id)
            .filter(Booking.user_id == user_id)
            .filter(Booking.is_active == True)
            .order_by(Booking.start_at.asc())
            .all()
        )

    def get_by_id_in_org(self, db: Session, organization_id: str, booking_id: int) -> Booking | None:
        return (
            db.query(Booking)
            .filter(Booking.organization_id == organization_id)
            .filter(Booking.id == booking_id)
            .filter(Booking.is_active == True)
            .first()
        )

    def get_by_id_for_user_in_org(self, db: Session, organization_id: str, booking_id: int, user_id: int) -> Booking | None:
        return (
            db.query(Booking)
            .filter(Booking.organization_id == organization_id)
            .filter(Booking.id == booking_id)
            .filter(Booking.user_id == user_id)
            .filter(Booking.is_active == True)
            .first()
        )

    def soft_delete_in_org(self, db: Session, organization_id: str, booking_id: int) -> bool:
        booking = (
            db.query(Booking)
            .filter(Booking.organization_id == organization_id)
            .filter(Booking.id == booking_id)
            .filter(Booking.is_active == True)
            .first()
        )
        if not booking:
            return False
        booking.is_active = False
        db.commit()
        return True

    def soft_delete_for_user_in_org(self, db: Session, organization_id: str, booking_id: int, user_id: int) -> bool:
        booking = (
            db.query(Booking)
            .filter(Booking.organization_id == organization_id)
            .filter(Booking.id == booking_id)
            .filter(Booking.user_id == user_id)
            .filter(Booking.is_active == True)
            .first()
        )
        if not booking:
            return False
        booking.is_active = False
        db.commit()
        return True

    def overlaps(self, db: Session, organization_id: str, space_id: int, start_at: datetime, end_at: datetime) -> bool:
        existing = (
            db.query(Booking)
            .filter(Booking.organization_id == organization_id)
            .filter(Booking.space_id == space_id)
            .filter(Booking.is_active == True)
            .filter(Booking.status.in_(["approved", "pending"]))
            .filter(and_(Booking.start_at < end_at, Booking.end_at > start_at))
            .first()
        )
        return existing is not None

    def list_conflicts_for_space(
        self,
        db: Session,
        organization_id: str,
        space_id: int,
        from_at: datetime,
        to_at: datetime,
    ) -> list[Booking]:
        return (
            db.query(Booking)
            .filter(Booking.organization_id == organization_id)
            .filter(Booking.space_id == space_id)
            .filter(Booking.is_active == True)
            .filter(Booking.status.in_(["approved", "pending"]))
            .filter(
                or_(
                    and_(
                        Booking.enter_time.isnot(None),
                        Booking.leave_time.isnot(None),
                        Booking.enter_time < to_at,
                        Booking.leave_time > from_at,
                    ),
                    and_(
                        Booking.enter_time.is_(None),
                        Booking.leave_time.is_(None),
                        Booking.start_at < to_at,
                        Booking.end_at > from_at,
                    ),
                )
            )
            .order_by(Booking.start_at.asc())
            .all()
        )
    
    def list_by_status_in_org(
        self,
        db: Session,
        organization_id: str,
        status: str,
    ) -> list[Booking]:
        return(
            db.query(Booking)
            .filter(Booking.organization_id == organization_id)
            .filter(Booking.status == status)
            .filter(Booking.is_active == True)
            .order_by(Booking.start_at.asc())
            .all()
        )
    
    def list_pending_for_approver(
        self,
        db: Session,
        organization_id: str,
        approver_user_public_id: str,
    ) -> list[Booking]:
        return (
            db.query(Booking)
            .join(Space, Booking.space_id == Space.id)
            .join(SpaceApprover, Space.public_id == SpaceApprover.space_id)
            .join(UserGroup, UserGroup.group_id == SpaceApprover.group_id)
            .filter(Booking.organization_id == organization_id)
            .filter(Booking.status == "pending")
            .filter(Booking.is_active == True)
            .filter(UserGroup.user_id == approver_user_public_id)
            .order_by(Booking.start_at.asc())
            .all()
        )