from sqlalchemy.orm import Session

from app.models import Organization
from app.services.sample_data import create_sample_data


class OrganizationRepository:
    def get_by_id(self, db: Session, org_id: str) -> Organization | None:
        return db.query(Organization).filter(Organization.id == org_id).first()

    def create(self, db: Session, org_id: str, name: str) -> Organization:
        org = Organization(id=org_id, name=name)
        db.add(org)
        db.commit()
        db.refresh(org)

        # ✅ come in Go: dopo la creazione org, crea Sample Floor + mappa + desk
        create_sample_data(db, org.id)

        return org