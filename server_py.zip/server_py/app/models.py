import uuid
from datetime import datetime

from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    ForeignKey,
    Integer,
    String,
    LargeBinary,
    Float,
    UniqueConstraint
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship

from app.core.database import Base


class Organization(Base):
    __tablename__ = "organizations"

    id = Column(String, primary_key=True, index=True)  
    name = Column(String, nullable=False)

    users = relationship("User", back_populates="organization")
    locations = relationship("Location", back_populates="organization")
    spaces = relationship("Space", back_populates="organization")
    bookings = relationship("Booking", back_populates="organization")


class Location(Base):
    __tablename__ = "locations"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, index=True)
    organization_id = Column(String, ForeignKey("organizations.id"), nullable=False, index=True)

    name = Column(String, nullable=False)

    map_mimetype = Column(String, nullable=False, default="")
    map_data = Column(LargeBinary, nullable=True)
    map_width = Column(Integer, nullable=False, default=0)
    map_height = Column(Integer, nullable=False, default=0)
    map_scale = Column(Float, nullable=False, default=1.0)

    description = Column(String, nullable=False, default="")
    max_concurrent_bookings = Column(Integer, nullable=False, default=0)

    timezone = Column(String, nullable=False, default="")  
    enabled = Column(Boolean, nullable=False, default=True)

    organization = relationship("Organization", back_populates="locations")
    spaces = relationship("Space", back_populates="location_rel")


class Space(Base):
    __tablename__ = "spaces"

    # PK UUID (così puoi usare l'id come in Go)
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, index=True)

    # Public ID (compat con tabelle di join che puntano a public_id)
    public_id = Column(UUID(as_uuid=True), unique=True, default=uuid.uuid4, index=True, nullable=False)

    organization_id = Column(String, ForeignKey("organizations.id"), nullable=False, index=True)

    location_id = Column(UUID(as_uuid=True), ForeignKey("locations.id"), nullable=False, index=True)

    name = Column(String, nullable=False)

    kind = Column(String, nullable=False, default="desk")
    capacity = Column(Integer, nullable=True)
    location = Column(String, nullable=True)
    is_active = Column(Boolean, nullable=False, default=True)

    x = Column(Integer, nullable=True)
    y = Column(Integer, nullable=True)
    width = Column(Integer, nullable=True)
    height = Column(Integer, nullable=True)
    rotation = Column(Integer, nullable=True)
    require_subject = Column(Boolean, nullable=False, default=True)

    organization = relationship("Organization", back_populates="spaces")
    location_rel = relationship("Location", back_populates="spaces")
    bookings = relationship("Booking", back_populates="space")


class Booking(Base):
    __tablename__ = "bookings"

    id = Column(Integer, primary_key=True, index=True)
    public_id = Column(UUID(as_uuid=True), unique=True, default=uuid.uuid4, index=True, nullable=False)

    organization_id = Column(String, ForeignKey("organizations.id"), nullable=False, index=True)
    space_id = Column(UUID(as_uuid=True), ForeignKey("spaces.id"), nullable=False, index=True)
    
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)

    start_at = Column(DateTime, nullable=False, index=True)
    end_at = Column(DateTime, nullable=False, index=True)

    enter_time = Column(DateTime, nullable=True, index=True)
    leave_time = Column(DateTime, nullable=True, index=True)
    subject = Column(String, nullable=True)
    recurring_id = Column(String, nullable=True)

    status = Column(String, nullable=False, default="approved", index=True)
    
    approved_by = Column(UUID(as_uuid=True), ForeignKey("users.public_id", ondelete="SET NULL"), nullable=True)
    approved_at = Column(DateTime, nullable=True)

    is_active = Column(Boolean, nullable=False, default=True, index=True)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)

    space = relationship("Space", back_populates="bookings")
    user = relationship("User", back_populates="bookings", foreign_keys=[user_id])
    organization = relationship("Organization", back_populates="bookings")
    approver = relationship("User", foreign_keys=[approved_by])

    



class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)

    public_id = Column(UUID(as_uuid=True), unique=True, default=uuid.uuid4, index=True, nullable=False)

    email = Column(String, unique=True, index=True, nullable=False)
    full_name = Column(String, nullable=True)
    hashed_password = Column(String, nullable=False)

    organization_id = Column(String, ForeignKey("organizations.id"), nullable=True)

    organization = relationship("Organization", back_populates="users")

    role = Column(String, nullable=False, default="user")
    bookings = relationship("Booking", back_populates="user", foreign_keys="Booking.user_id")


class SpaceApprover(Base):
    __tablename__ = "spaces_approvers"

    space_id = Column(UUID(as_uuid=True), ForeignKey("spaces.public_id"), primary_key=True)
    group_id = Column(UUID(as_uuid=True), primary_key=True)



class SpaceAllowedBooker(Base):
    __tablename__ = "spaces_allowed_bookers"

    space_id = Column(UUID(as_uuid=True), ForeignKey("spaces.public_id"), primary_key=True)
    group_id = Column(UUID(as_uuid=True), primary_key=True)



class Group(Base):
    __tablename__ = "groups"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id = Column(String, ForeignKey("organizations.id"), nullable=False, index=True)
    name = Column(String, nullable=False)

    __table_args__ = (
        UniqueConstraint("organization_id", "name", name="uq_groups_org_name"),
    )


class UserGroup(Base):
    __tablename__ = "users_groups"

    group_id = Column(UUID(as_uuid=True), ForeignKey("groups.id", ondelete="CASCADE"), primary_key=True)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.public_id", ondelete="CASCADE"), primary_key=True)