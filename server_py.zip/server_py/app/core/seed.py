import os
from sqlalchemy.orm import Session

from app.models import Organization, User
from app.core.security import hash_password
from app.services.sample_data import create_sample_data


def seed_db(db: Session) -> None:
    org_id = os.getenv("SEED_ORG_ID", "seatsurfing")
    org_name = os.getenv("SEED_ORG_NAME", "Seatsurfing")
    admin_email = os.getenv("SEED_ADMIN_EMAIL", "admin@seatsurfing.local")
    admin_password = os.getenv("SEED_ADMIN_PASSWORD", "12345678")

    # 1) Organization
    org = db.query(Organization).filter(Organization.id == org_id).first()
    if not org:
        org = Organization(id=org_id, name=org_name)
        db.add(org)
        db.commit()
        db.refresh(org)

    # 2) Sample data (idempotente)
    create_sample_data(db, org.id)

    # 3) Admin user
    user = db.query(User).filter(User.email == admin_email).first()
    if not user:
        user = User(
            email=admin_email,
            full_name="Admin",
            organization_id=org.id,
            role="org_admin",
            hashed_password=hash_password(admin_password),
        )
        db.add(user)
        db.commit()
        return

    # 4) Se esiste: allinea org e role
    changed = False

    if user.organization_id != org.id:
        user.organization_id = org.id
        changed = True

    if user.role != "org_admin":
        user.role = "org_admin"
        changed = True

    if not user.hashed_password:
        user.hashed_password = hash_password(admin_password)
        changed = True

    if changed:
        db.commit()